---------------------------------------------------------------------------------

This file is part of the MU-principles repository


Authors: Francesca Bevilacqua, Alessandro Lanza, 
         Monica Pragliola, Fiorella Sgallari

Paper: F. Bevilacqua, A. Lanza, M. Pragliola, F. Sgallari (2023) 
          Masked unbiased principles for parameter selection in
          variational image restoration under Poisson noise.
          Inverse Problems, Volume 39, Number 3, doi:10.1088/1361-6420/acb0f7.
          https://iopscience.iop.org/article/10.1088/1361-6420/acb0f7/pdf

Last update: February 27, 2023

-------------------------------------------------------------------------------------------

The MU-principles repository is a Matlab repository for the comparison of
different selection principles for the selection of the regularization parameter 
in the image restoration variational models

  TV-KL: x_hat = argmin { TV(u) + mu * KL(Hx+b;y) }
                     u

  TV2-KL: x_hat = argmin { TV2(u) + mu * KL(Hx+b;y) }
                      u

under Poisson noise degradation.

Codes have been tested on Matlab R2022b

The MU-principles repository contains:

 - MAIN_CODE: main code TO RUN    
 - input folder: it contains the test images satellite and stem used in the tests
 - GENERATE_BLURRED_DATA: it generates the blurred image Hx
 - DEFINE_MU_RANGE_and_ADMM_PARAMETERS: it contains the selection of the parameters
   for reproducing the tests reported in the paper
 - INITIALIZE: it constains the definition and/or the initialization of the strategy measures  
 - TV_KL_U_ADMM: ADMM for the unconstrained TV-KL for the restoration task under 
   Poisson noise degradation. As in the paper, it is employed for the restoration of satellite
 - TV2_KL_U_ADMM: ADMM for the unconstrained TV2-KL for the restoration task under 
   Poisson noise degradation. As in the paper, it is employed for the restoration of stem
 - compute_snr: it computes the Signal-to-Noise-Ratio between a signal and its reference
 - CREATE_FIGURES: it generates the figures for comparing the methods
                               




