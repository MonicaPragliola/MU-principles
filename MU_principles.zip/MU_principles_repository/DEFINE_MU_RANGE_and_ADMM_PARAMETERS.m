% Define the parameters for the ADMM and the range of the regularization
% parameter
switch im_id   
    case 1  % SATELLITE ---------------------------------------------------
        if fact_k<=1
            mu_min  = 0.01; 
            mu_max  = 3.5; 
            mus_n   = 50; 
            gamma_ADMM = 30; 
        elseif fact_k <= 3
            mu_min  = 0.5; 
            mu_max  = 5; 
            mus_n   = 50; 
            gamma_ADMM = 10; 
        elseif fact_k <= 5
            mu_min  = 0.5; 
            mu_max  = 8; 
            mus_n   = 50; 
            gamma_ADMM = 10;
        elseif fact_k <= 10
            mu_min  = .1; 
            mu_max  = 15; 
            mus_n   = 50;
            gamma_ADMM = 8;     
        elseif fact_k <= 20
            mu_min  = 0.1;
            mu_max  = 18;  
            mus_n   = 50;  
            gamma_ADMM = 8;     
        elseif fact_k <= 50
            mu_min  = 2; 
            mu_max  = 50; 
            mus_n   = 50;
            gamma_ADMM = 8;    
        elseif fact_k <= 110
            mu_min  = 7; 
            mu_max  = 50;
            mus_n   = 50;
            gamma_ADMM = 5;  
        elseif fact_k <=500
            mu_min  = 10; 
            mu_max  = 150;
            mus_n   = 50;
            gamma_ADMM = 1; 
        else
            mu_min  = 40; 
            mu_max  = 300;
            mus_n   = 50;
            gamma_ADMM = 0.1;  
        end
    case 2  % STEM 2 ---------------------------------------------------
        if fact_k <=1
            mu_min  = 0.01; 
            mu_max  = 1; 
            mus_n   = 50; 
            gamma_ADMM = 30; 
        elseif fact_k <= 3
            mu_min  = 0.1; 
            mu_max  = 2; 
            mus_n   = 50;  
            gamma_ADMM = 10;
        elseif fact_k <= 5
            mu_min  = 0.1; 
            mu_max  = 2.2; 
            mus_n   = 50; 
            gamma_ADMM = 10;
        elseif fact_k <= 10
            mu_min  =  0.1; 
            mu_max  =  8; 
            mus_n   = 50;
            gamma_ADMM = 8;      
        elseif fact_k <= 20
            mu_min  = 0.1;
            mu_max  = 12;
            mus_n   = 30;  
            gamma_ADMM = 8;     
        elseif fact_k <= 50
            mu_min  = 0.1; 
            mu_max  = 12; 
            mus_n   = 50;
            gamma_ADMM = 8;    
        elseif fact_k <= 110
            mu_min  = 2; 
            mu_max  = 18;
            mus_n   = 50;
            gamma_ADMM = 5;  
        elseif fact_k <=500
            mu_min  = 6; 
            mu_max  = 55;
            mus_n   = 50;
            gamma_ADMM = 1;
        else
            mu_min  = 10; 
            mu_max  = 80;
            mus_n   = 50;
            gamma_ADMM = 0.1;  
        end
        
end


% Define the parameters for the ADMM
itr_th         = 5000;  % Maximum number of iterations
rel_chg_th     = 1e-5;  % Relative change for the stopping criteria
debug          = 0;     % set = 0 for no debug information and = 1 for information along the iterations

% Initialize the Lagrange multipliers according to the choosen regularizer
if regularizer_id == 1  % TV regularization
    rho_u1    = zeros(size(y_data));
    rho_u2    = zeros(size(y_data));
    rho_u3_h  = zeros(size(y_data));
    rho_u3_v  = zeros(size(y_data));
    
elseif regularizer_id == 2 % TV2 regularization
    rho_u1    = zeros(size(y_data));
    rho_u2    = zeros(size(y_data));
    rho_u3_hh = zeros(size(y_data));
    rho_u3_vv = zeros(size(y_data));
    rho_u3_hv = zeros(size(y_data));   
end
