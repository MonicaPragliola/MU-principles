% Plot the ISNR and SSIM achieved on the grid of the considered mus.
% The different strategies are detected by vertical lines.
figure(1)
set(gcf, 'Position', get(0, 'Screensize'));
sgtitle(['ISNR (solid blue) and SSIM (solid red) values ' ...
    'of the restored images as a function of mu and the mu values selected ' ...
    'by the compared approaches (vertical lines)'])
% ADP and ADP-M
subplot(2,2,1)
% ISNR
yyaxis left;
x_min = mu_min;
x_max = mu_max;
y_min = min(ISNRS);
y_max = max(ISNRS)*1.2;
plot([mu_ADP,mu_ADP],[y_min,y_max],'b-.','LineWidth',1.5);
hold on;
plot([mu_ADP_M,mu_ADP_M],[y_min,y_max],'r-.','LineWidth',1.5);
hold all;
plot(mus,ISNRS,'-','LineWidth',1.5);
xlabel('$\mu$','Interpreter','latex');
ylabel('ISNR');
axis([x_min,x_max,y_min,y_max])
% SSIM
yyaxis right;
plot(mus,SSIMS,'-','LineWidth',1.5); hold all;
ylabel('SSIM');
z_min = min(SSIMS);
z_max = max(SSIMS)*1.2;
axis([x_min,x_max,z_min,z_max])
legend('$\mu^{(ADP)}$','$\mu^{(ADP-M)}$','Interpreter','latex');
title('Approximate')

% QDP, QDP-MU and QDP-MB
subplot(2,2,2)
% ISNR
yyaxis left;
x_min = mu_min;
x_max = mu_max;
y_min = min(ISNRS);
y_max = max(ISNRS)*1.2;
plot([mu_QDP,mu_QDP],[y_min,y_max],'b-.','LineWidth',1.5);
hold on;
plot([mu_QDP_MU,mu_QDP_MU],[y_min,y_max],'r-.','LineWidth',1.5);
hold all;
plot([mu_QDP_MB,mu_QDP_MB],[y_min,y_max],'g-.','LineWidth',1.5);
plot(mus,ISNRS,'-','LineWidth',1.5);
xlabel('$\mu$','Interpreter','latex');
ylabel('ISNR');
axis([x_min,x_max,y_min,y_max])
% SSIM
yyaxis right;
plot(mus,SSIMS,'-','LineWidth',1.5); hold all;
ylabel('SSIM');
z_min = min(SSIMS);
z_max = max(SSIMS)*1.2;
axis([x_min,x_max,z_min,z_max])
legend('$\mu^{(QDP)}$','$\mu^{(QDP-MU)}$','$\mu^{(QDP-MB)}$','Interpreter','latex');
title('Quadratic')

% NEDP, NEDP-MU and NEDP-MB
subplot(2,2,3)
% ISNR
yyaxis left;
x_min = mu_min;
x_max = mu_max;
y_min = min(ISNRS);
y_max = max(ISNRS)*1.2;
plot([mu_NEDP,mu_NEDP],[y_min,y_max],'b-.','LineWidth',1.5);
hold on;
plot([mu_NEDP_MU,mu_NEDP_MU],[y_min,y_max],'r-.','LineWidth',1.5);
hold all;
plot([mu_NEDP_MB,mu_NEDP_MB],[y_min,y_max],'g-.','LineWidth',1.5);
plot(mus,ISNRS,'-','LineWidth',1.5);
xlabel('$\mu$','Interpreter','latex');
ylabel('ISNR');
axis([x_min,x_max,y_min,y_max])
% SSIM
yyaxis right;
plot(mus,SSIMS,'-','LineWidth',1.5); hold all;
ylabel('SSIM');
z_min = min(SSIMS);
z_max = max(SSIMS)*1.2;
axis([x_min,x_max,z_min,z_max])
legend('$\mu^{(NEDP)}$','$\mu^{(NEDP-MU)}$','$\mu^{(NEDP-MB)}$','Interpreter','latex');
title('Nearly Exact')

% WP, WP-MU and WP-MB
subplot(2,2,4)
% ISNR
yyaxis left;
x_min = mu_min;
x_max = mu_max;
y_min = min(ISNRS);
y_max = max(ISNRS)*1.2;
plot([mu_WP,mu_WP],[y_min,y_max],'b-.','LineWidth',1.5);
hold on;
plot([mu_WP_MU,mu_WP_MU],[y_min,y_max],'r-.','LineWidth',1.5);
hold all;
plot([mu_WP_MB,mu_WP_MB],[y_min,y_max],'g-.','LineWidth',1.5);
plot(mus,ISNRS,'-','LineWidth',1.5);
xlabel('$\mu$','Interpreter','latex');
ylabel('ISNR');
axis([x_min,x_max,y_min,y_max])
% SSIM
yyaxis right;
plot(mus,SSIMS,'-','LineWidth',1.5); hold all;
ylabel('SSIM');
z_min = min(SSIMS);
z_max = max(SSIMS)*1.2;
axis([x_min,x_max,z_min,z_max])
legend('$\mu^{(WP)}$','$\mu^{(WP-MU)}$','$\mu^{(WP-MB)}$','Interpreter','latex');
title('Whiteness')

if plot_strategy_measures==1

    figure(2)
    set(gcf, 'Position', get(0, 'Screensize'));
    sgtitle('Left-hand side values of the discrepancy equation as a function of mu for the Approximate discrepancy principles')
    subplot(1,2,1)
    plot(mus,Discrepancy_equation_ADP,'r-','LineWidth',1.5)
    xlabel('$\mu$','Interpreter','latex');
    yline(0)
    legend('$\mathcal{D}(\mu;y) - \Delta^{(A)}$','Interpreter','latex')
    title('ADP')
    subplot(1,2,2)
    plot(mus,Discrepancy_equation_ADP_M,'b-','LineWidth',1.5)
    yline(0)
    xlabel('$\mu$','Interpreter','latex');
    legend('$\mathcal{D}_{+}(\mu;y) - \Delta_{+}^{(A)}$','Interpreter','latex')
    title('ADP-M')

    figure(3)
    set(gcf, 'Position', get(0, 'Screensize'));
    sgtitle('Left-hand side values of the discrepancy equation as a function of mu for the Quadratic discrepancy principles')
    subplot(2,4,[1,2])
    plot(mus,QUADRATIC_measure,'r-','LineWidth',1.5)
    yline(0)
    xlabel('$\mu$','Interpreter','latex');
    legend('$\mathcal{D}^{(Q)}(\mu;y) - \Delta^{(Q)}$','Interpreter','latex')
    title('QDP')
    subplot(2,4,[3,4])
    plot(mus,QUADRATIC_measure_MU,'g-','LineWidth',1.5)
    yline(0)
    xlabel('$\mu$','Interpreter','latex');
    legend('$\mathcal{D}_{+}^{(QU)}(\mu;y) - \Delta_{+}^{(QU)}$','Interpreter','latex')
    title('QDP-MU')
    subplot(2,4,[6,7])
    plot(mus,QUADRATIC_measure_MB,'b-','LineWidth',1.5)
    yline(0)
    xlabel('$\mu$','Interpreter','latex');
    legend('$\mathcal{D}_{+}^{(Q)}(\mu;y) - \Delta_{+}^{(Q)}$','Interpreter','latex')
    title('QDP-MB')

    figure(4)
    set(gcf, 'Position', get(0, 'Screensize'));
    sgtitle('Left-hand side values of the discrepancy equation as a function of mu for the Nearly-Exact discrepancy principles')
    subplot(2,4,[1,2])
    plot(mus,Discrepancy_equation_NEDP,'r-','LineWidth',1.5)
    yline(0)
    xlabel('$\mu$','Interpreter','latex');
    legend('$\mathcal{D}(\mu;y) - \Delta^{(NE)}$','Interpreter','latex')
    title('NEDP')
    subplot(2,4,[3,4])
    plot(mus,Discrepancy_equation_NEDP_MU,'g-','LineWidth',1.5)
    yline(0)
    xlabel('$\mu$','Interpreter','latex');
    legend('$\mathcal{D}_{+}(\mu;y) - \Delta_{+}^{(NE-MU)}$','Interpreter','latex')
    title('NEDP-MU')
    subplot(2,4,[6,7])
    plot(mus,Discrepancy_equation_NEDP_MU,'b-','LineWidth',1.5)
    yline(0)
    xlabel('$\mu$','Interpreter','latex');
    legend('$\mathcal{D}_{+}(\mu;y) - \Delta_{+}^{(NE)}$','Interpreter','latex')
    title('NEDP-MB')
    
    figure(5)
    set(gcf, 'Position', get(0, 'Screensize'));
    sgtitle('Whiteness measure values as function of mu for the Whiteness principles')
    subplot(2,4,[1,2])
    plot(mus,WHITENESS_measure,'r-','LineWidth',1.5)
    xline(mu_WP,'k-')
    xlabel('$\mu$','Interpreter','latex');
    legend('$W(\mu)$','Interpreter','latex')
    title('WP')
    subplot(2,4,[3,4])
    plot(mus,WHITENESS_measure_MU,'g-','LineWidth',1.5);
    xline(mu_WP_MU,'k-')
    xlabel('$\mu$','Interpreter','latex');
    legend('$W_{+}^{(U)}(\mu)$','Interpreter','latex')
    title('WP-MU')
    subplot(2,4,[6,7])
    plot(mus,WHITENESS_measure_MB,'b-','LineWidth',1.5)
    xline(mu_WP_MB,'k-')
    xlabel('$\mu$','Interpreter','latex');
    legend('$W_{+}(\mu)$','Interpreter','latex')
    title('WP-MB')

end

if show_reconstructions==1
    figure(6)
    set(gcf, 'Position', get(0, 'Screensize'));
    sgtitle('Restored images obtained by using the eleven selection approaches')
    subplot(6,12,[13,14,25,26])
    imshow(uint8(255*xtr/fact_k));
    title('Original')
    subplot(6,12,[15,16,27,28])
    imshow(uint8(255*y_data/fact_k));
    title('Data')
    subplot(6,12,[37,38,49,50])
    imshow(uint8(255*x_hat_ISNR/fact_k));
    title('Best ISNR')
    subplot(6,12,[39,40,51,52])
    imshow(uint8(255*x_hat_SSIM/fact_k));
    title('Best SSIM')
    
    subplot(6,12,[5,6,17,18])
    imshow(uint8(255*x_hat_ADP/fact_k));
    title('ADP')
    subplot(6,12,[29,30,41,42])
    imshow(uint8(255*x_hat_ADP_M/fact_k));
    title('ADP-M')
    
    subplot(6,12,[7,8,19,20])
    imshow(uint8(255*x_hat_QDP/fact_k));
    title('QDP')
    subplot(6,12,[31,32,43,44])
    imshow(uint8(255*x_hat_QDP_MB/fact_k));
    title('QDP-MB')
    subplot(6,12,[55,56,67,68])
    imshow(uint8(255*x_hat_QDP_MU/fact_k));
    title('QDP-MU')
    
    subplot(6,12,[9,10,21,22])
    imshow(uint8(255*x_hat_NEDP/fact_k));
    title('NEDP')
    subplot(6,12,[33,34,45,46])
    imshow(uint8(255*x_hat_NEDP_MB/fact_k));
    title('NEDP-MB')
    subplot(6,12,[57,58,69,70])
    imshow(uint8(255*x_hat_NEDP_MU/fact_k));
    title('NEDP-MU')
    
    subplot(6,12,[11,12,23,24])
    imshow(uint8(255*x_hat_WP/fact_k));
    title('WP')
    subplot(6,12,[35,36,47,48])
    imshow(uint8(255*x_hat_WP_MB/fact_k));
    title('WP-MB')
    subplot(6,12,[59,60,71,72])
    imshow(uint8(255*x_hat_WP_MU/fact_k));
    title('WP-MU')
end

