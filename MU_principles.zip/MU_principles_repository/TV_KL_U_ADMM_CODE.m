function [u1,u2,rho_u3_h,rho_u3_v,rho_u2,rho_u1,itrs] = ...
    TV_KL_U_ADMM_CODE(y,blur_k,mu,gamma,x,b,rho_u3_h,rho_u3_v,rho_u2,rho_u1,itrs_th,itrs_rel_chg_th,itrs_debugs,x_true)
%
% Compute approximate solutions (that is, minimizers) of the
% unconstrained TV-KL variational model: 
%
% x_hat(mu) = argmin J(x;mu),   J(x;mu) = TV(x) + mu * KL(lambda;y)
%                x
%
%
% INPUTS:
    % inputs defining the unconstrained TV-KL cost function to be minimized:
        % y         --> observed corrupted (blurred and noisy) image
        % blur_h    --> blur PSF (kernel of spatial 2D convolution)
        % mu        --> regularization parameter (positive real scalar) 
        % b         --> background 
    % inputs defining the ADMM (iterative) algorithm:
        % gamma     --> penalty (positive real scalar)
        % x         --> initial iterate (usually, but not necessarily, the observed corrupted image y)         
        % rho_u1    --> Lagrange multipliers associated with the introduced auxiliary variable u1 = x
        % rho_u2    --> Lagrange multipliers associated with the introduced auxiliary variable u2 = Hx
        % rho_u3_h  --> Lagrange multipliers associated with the introduced auxiliary variable u3_h = Dh(x)
        % rho_u3_v  --> Lagrange multipliers associated with the introduced auxiliary variable u3_v = Dv(x)
        % ADMM stopping criteria:
            % itrs_th         --> threshold: maximum number of ADMM iterations
            % itrs_rel_chg_th --> threshold: iterates relative change

    % (optional) inputs defining eventual "debugs" 
        % itrs_debugs --> flag: 0->no debug; 1->debug
        % x_true      --> original uncorrupted image
        
% We remark the following:
%   - all images are stored as matrices, that is they are not vectorized!
%   - periodic boundary conditions are assumed for the unknown clean image 
%     to restore, that is both the blur and the first-order derivatives 
%     near the image boundaries are computed according to this assumption!
%     This assumption allows to diagonalize the blur matrix K and the 
%     first-order horizontal and vertical partial derivative matrices
%     Dh and Dv by means of the 2D Discrete Fourier Transform (DFT)
    
% --------------------
% initialize algorithm
% --------------------
    
% extract image dimensions
[h,w] = size(y); % height and width, in pixels
    
% given the inputs y, blur_k, mu,  for efficiency purposes 
% compute/store once for all at the beginning (here) all the quantities 
% that will be used for the solution of the ADMM algorithm sub-problems 
% but that do not change during the ADMM iterations

    % sub-problem for the primal variable u3 (shrinkage)
    one_over_gamma   = 1 / (gamma); % constant in the shrinkage
    
    % sub-problem for the primal variable u2 (shrinkage)
    mu_over_gamma    = mu / gamma; % constant in the shrinkage
    mu_over_gamma_y  = mu_over_gamma * y;
    
    % sub-problem for the primal variable x (linear system)

    H_DFT              = psf2otf(blur_k,[h,w]); % 2D DFT for blur matrix H
    Dh_DFT             = psf2otf([1,-1],[h,w]); % 2D DFT for finite difference matrix Dh
    Dv_DFT             = psf2otf([1;-1],[h,w]); % 2D DFT for finite difference matrix Dv
    HT_DFT             = conj(H_DFT);  % 2D DFT for transpose of blur matrix H
    DhT_DFT            = conj(Dh_DFT); % 2D DFT for transpose of finite difference matrix Dh
    DvT_DFT            = conj(Dv_DFT); % 2D DFT for transpose of finite difference matrix Dv
    SUB_X_CM_DFT       = DhT_DFT .* Dh_DFT + DvT_DFT .* Dv_DFT +  (HT_DFT .* H_DFT)+ones(h,w);

    
            
% initialize other necessary quantities
    % gradient of the initial iterate x
    [Dhx,Dvx] = D(x); 
    % blurred image associated with the initial iterate x
    Hx        = real(ifft2( H_DFT .* fft2(x) ));
    
% --------------------------------------
% (eventually) compute/store/show debugs
% --------------------------------------
if ( itrs_debugs == 1 )
    y_snr         = compute_snr(y,x_true);
    % allocate arrays where storing iterations-based debug quantities
    rel_chgs      = zeros(1,itrs_th);
    snrs          = zeros(1,itrs_th+1);
    ssims         = zeros(1,itrs_th+1);

    % compute/initialize and store iterations-based debug quantities
    snrs(1)       = compute_snr(x,x_true);
    ssims(1)      = ssim(x,x_true);  

    % Matlab command window debugs
    fprintf('\n---------------------------------------------------------');
    fprintf('\nTV-KL-U-ADMM (mu = %7.2f) ITERATIONS-BASED DEBUGS:',mu);
    fprintf('\n---------------------------------------------------------');
    fprintf('\nIT %04d:  RC = %12.10f, [ISNR,SSIM] = [%8.5f , %8.6f]',...
        0,0,snrs(1)-y_snr,ssims(1));
end

    

% -------------------------
% carry out ADMM iterations
% -------------------------

% initialize iteration index and stopping criteria flags
itrs        = 0;   
stop_flags  = [0,0];

% while stopping criteria are not satisfied...iterate
while ( sum(stop_flags) == 0 )
    
    % update iteration index
    itrs = itrs + 1;
    
    % ----------------------------------------------------------------
    % solve the ADMM sub-problem for the primal variable u3 (shrinkage)
    % ----------------------------------------------------------------
    q_h                 = Dhx + rho_u3_h;
    q_v                 = Dvx + rho_u3_v;
    q_norm              = sqrt( q_h.^2 + q_v.^2 );
    q_norm(q_norm == 0) = one_over_gamma;
    q_norm              = max( q_norm - one_over_gamma , 0 ) ./ q_norm;
    u3_h                 = q_norm .* q_h;
    u3_v                 = q_norm .* q_v;
    
    % ----------------------------------------------------------------
    % solve the ADMM sub-problem for the primal variable u2 
    % ----------------------------------------------------------------
    zz        = ( Hx + (rho_u2 - mu_over_gamma)+b ) / 2;
    r         = max( zz + sqrt(zz.^2 + mu_over_gamma_y),b); 
    u2         = r-b;
    
    % --------------------------------------------------------------------
    % solve the ADMM sub-problem for the primal variable u1 (projection)
    % --------------------------------------------------------------------
    u1     = max(x+rho_u1,0);
    
    % --------------------------------------------------------------------
    % solve the ADMM sub-problem for the primal variable x (linear system)
    % --------------------------------------------------------------------
        
    % store u_old for future computation of iterates relative change
    x_old       = x; 
    % compute the (DFT of the) right-hand side of the linear system
    rhs_DFT     = fft2( DT(u3_h - rho_u3_h,u3_v - rho_u3_v) ) + ... 
                  HT_DFT .* fft2(u2 - rho_u2)+fft2(u1-rho_u1);
    % compute the (DFT of the) new iterate
    x_DFT       = rhs_DFT ./ SUB_X_CM_DFT;
    % compute the new iterate
    x           = real(ifft2(x_DFT));
                   
    % --------------------------------------------------
    % compute u relative change (for stopping criterion)
    % --------------------------------------------------
    rel_chg = norm(x - x_old,'fro') / norm(x_old,'fro');
    
    % -----------------------
    % check stopping criteria
    % -----------------------
    if ( itrs == itrs_th )
        stop_flags(1) = 1;
    end
    if ( rel_chg < itrs_rel_chg_th )
        stop_flags(2) = 1;
    end
    
    % -------------------------------
    % compute quantities used for the 
    % subsequent lambdas update step
    % and for the next iteration
    % -------------------------------
    
        % gradient of the current iterate u
        [Dhx,Dvx] = D(x);
        % blurred image associated with the current iterate u
        Hx        = real(ifft2( H_DFT .* x_DFT ));
    
    % ------------------------------------------------------------------
    % update dual variables (Lagrange multipliers) lambdas (dual ascent)
    % ------------------------------------------------------------------
        
        % Lagrange multipliers associated with the auxiliary variable t = (th;tv)
        rho_u3_h = rho_u3_h - (u3_h - Dhx);
        rho_u3_v = rho_u3_v - (u3_v - Dvx);
        % Lagrange multipliers associated with the auxiliary variable r
        rho_u2   = rho_u2   - (u2 - Hx);
        % Lagrange multipliers associated with the auxiliary variable u1
        rho_u1   = rho_u1   - (u1 - x);
        
    % --------------------------------------
    % (eventually) compute/store/show debugs
    % --------------------------------------
    if ( itrs_debugs == 1 )
        % compute and store iterations-based debug quantities
        rel_chgs(itrs)     = rel_chg;
        snrs(itrs+1)       = compute_snr(x,x_true);
        ssims(itrs+1)      = ssim(x,x_true);
        % Matlab command window debugs
        fprintf('\nIT %04d:  RC = %12.10f, [ISNR,SSIM] = [%8.5f , %8.6f]',...
            itrs,rel_chgs(itrs),snrs(itrs+1)-y_snr,ssims(itrs+1));
    end
    
end







%-------------------------
% NESTED FUNCTIONS
%-------------------------
function [Dhu,Dvu] = D(u)
%
% Given the image u, compute Du , that is the gradient of u:
%       Du = (Dh u ; Dv u) ,
% with horizontal and vertical partial derivates (Dh u) and (Dv u) 
% both discretized by forward finite differences (kernel [-1,1])

Dhu = [ u(:,2:end) - u(:,1:(end-1)) , u(:,1) - u(:,end) ];
Dvu = [ u(2:end,:) - u(1:(end-1),:) ; u(1,:) - u(end,:) ]; 

end

function [DT_u12] = DT(u1,u2)
%
% Given the two images u1, u2, compute DT(u1;u2), that is:
%       DT(u1;u2) = Dh^T u1 + Dv^T u2,
% with horizontal and vertical partial derivates (Dh u) and (Dv u) 
% both discretized by forward finite differences (kernel [-1,1])

DhT_u1 = [ u1(:,end) - u1(:,1) , -diff(u1,1,2) ];
DvT_u2 = [ u2(end,:) - u2(1,:) ; -diff(u2,1,1) ];
DT_u12 = DhT_u1 + DvT_u2;

end


end


