% -------------------------------------------------------------------------
% SELECT THE ORIGINAL IMAGE TO BE TESTED
% im_id  index of the original image to be tested (see the switch-case below)
switch im_id    
    case 1 % satellite
        im_file     = './input/satellite.png';
        im_name     = 'satellite';
        f           = 255;
        xtr         = double(imread(im_file))/f;
        xtr(xtr<=0) = 0;   
    case 2 % stem2
        im_file     = './input/stem.jpg';
        im_name     = 'stem';
        f           = 255;
        esp         = double(imread(im_file))/f;
        xtr         = esp(:,:,1);
        xtr         = xtr./3;
        xtr(xtr<=0) = 0;
end

xtr             = xtr*fact_k;

% -------------------------------------------------------------------------
% SET THE BLUR PARAMETERS, THEN GENERATE AND STORE THE BLUR PSF (KERNEL) b_k, 
% FINALLY BLUR THE ORIGINAL IMAGE xtr --> K xtr

% set the Gaussian blur parameters then generate and store the blur kernel, b_k
b_r             = 2; % radius (pixels) ...the band is 2 * b_r + 1
b_s             = 1; % standard deviation
b_k             = fspecial('gaussian',(1 + 2 * b_r),b_s); % kernel
b_k = b_k / sum(b_k(:)); % normalize the kernel (actually, it is done by fspecial!)
    
% compute and store the blurred image, assuming for the blur kernel
% periodic boundary condition so that H admits a diagonalization in the
% Fourier domain
H_DFT = psf2otf(b_k,size(xtr)); 
Hxtr  = real( ifft2( H_DFT .* fft2(xtr) ) );

