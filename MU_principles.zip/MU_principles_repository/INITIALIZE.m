% Initialize the vectors that will contain the discrepancy function, i.e.
% the KL fidelity regarded as a function of mu
DISCREPANCY_function        = NaN(mus_n,1); % Discrepancy function for the unmasked case
DISCREPANCY_function_Masked = NaN(mus_n,1); % Discrepancy function for the masked cases

% Calculate the discrepancy values and initialize the others
Delta_ADP      = numel(Hxtr) / 2;
Delta_ADP_M    = sum(I_plus(:)) / 2;
Delta_QDP      = numel(Hxtr);
Delta_QDP_MB   = sum(I_plus(:));
Delta_QDP_MU   = sum(I_plus(:));
Delta_NEDP     = NaN(mus_n,1);
Delta_NEDP_MU  = NaN(mus_n,1);
Delta_NEDP_MB  = NaN(mus_n,1); 

% Initialize the left-hand side values of the discrepancy equations
% D - \Delta^(A) = 0,   D_+ - \Delta_+^(A) = 0
Discrepancy_equation_ADP     = NaN(mus_n,1);
Discrepancy_equation_ADP_M   = NaN(mus_n,1);
% D^(Q) - \Delta^(Q) = 0,   D_+^(Q) - \Delta_+^(Q) = 0,  D_+^(QU) - \Delta_+^(QU) = 0
QUADRATIC_measure            = NaN(mus_n,1); 
QUADRATIC_measure_MB         = NaN(mus_n,1);
QUADRATIC_measure_MU         = NaN(mus_n,1); 
% D - \Delta^(NE) = 0,   D_+ - \Delta_+^(NE) = 0,  D_+ - \Delta_+^(NE-U) = 0
Discrepancy_equation_NEDP    = NaN(mus_n,1);
Discrepancy_equation_NEDP_MB = NaN(mus_n,1);
Discrepancy_equation_NEDP_MU = NaN(mus_n,1);

% Initialize the whiteness measures to be minimized, namely W, W_+, W_+^(U)
WHITENESS_measure            = NaN(mus_n,1);
WHITENESS_measure_MB         = NaN(mus_n,1);
WHITENESS_measure_MU         = NaN(mus_n,1);

% Initialize the vectors for the ISNR and SSIM values of the reconstructed images
ISNRS          = NaN(mus_n,1);
SSIMS          = NaN(mus_n,1);

% Initialize the starting values for the above left-hand sides, whiteness
% measures and for the best ISNR/SSIM
Discrepancy_equation_ADP_old     = Inf;
Discrepancy_equation_ADP_M_old   = Inf;
QUADRATIC_measure_old            = Inf;
QUADRATIC_measure_MB_old         = Inf;
QUADRATIC_measure_MU_old         = Inf;
Discrepancy_equation_NEDP_old    = Inf;
Discrepancy_equation_NEDP_MB_old = Inf;
Discrepancy_equation_NEDP_MU_old = Inf;
WHITENESS_measure_old            = Inf;
WHITENESS_measure_MB_old         = Inf;
WHITENESS_measure_MU_old         = Inf;
max_ISNR_old                     = -Inf;
max_SSIM_old                     = -Inf;

% Initialize the matrices that will contain the selected reconstruction for
% each strategy
[rows,cols] = size(xtr);
x_hat_ADP         = NaN(rows,cols); 
x_hat_ADP_M       = NaN(rows,cols);
x_hat_QDP         = NaN(rows,cols);
x_hat_QDP_MB      = NaN(rows,cols);
x_hat_QDP_MU      = NaN(rows,cols);
x_hat_NEDP        = NaN(rows,cols);
x_hat_NEDP_MB     = NaN(rows,cols);
x_hat_NEDP_MU     = NaN(rows,cols);
x_hat_WP          = NaN(rows,cols);
x_hat_WP_MB       = NaN(rows,cols);
x_hat_WP_MU       = NaN(rows,cols);
x_hat_ISNR        = NaN(rows,cols);
x_hat_SSIM        = NaN(rows,cols);


% Define the coefficients for the nearly-exact estimate delta_NEDP
% of the exact expected value function and the function delta_NEDP
c1 = 5.556044442322159;
c2 = -2.983136889942212;
c3 = 16.584822942848039;
c4 = -7.087126550473653;
c5 = 32.745197797864080;
delta_NEDP   = @(y)(1/2)+(y.^2+c1.*y+c2)./(c3.*(y.^3)+c4.*(y.^2)+c5.*y-2.*c2);


% Define the coefficients for the nearly-exact estimate delta_NEDP_MU
% of the exact expected value function and the function delta_NEDP_MU
d1 = 30.743603445829962;
d2 = -2.296854310568803e+02;
d3 = 1.082718611777608e+02;
d4 = 90.192131910380695;
d5 = -1.887201206085006e+02;
d6 = 6.177828521437328e+02;
delta_NEDP_MU = @(y,I_plus) (1/2) + ((y(I_plus).^3) + d1*(y(I_plus).^2) + d2*y(I_plus)+ d3) ./ (12*(y(I_plus).^4) + d4*(y(I_plus).^3) + d5*(y(I_plus).^2) + d6*y(I_plus));
